#' Example datasets for SCnorm
#'
#' Data generated as in SIM I with K = 4
#'
#' @docType data
#'
#' @usage data(ExampleData)
#'
#' @format data matrix
#'
#' @keywords datasets
#'
#' @examples
#' data(ExampleData)
"ExampleData"